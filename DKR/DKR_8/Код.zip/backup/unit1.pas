unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Buttons, StdCtrls,
  EditBtn, ExtCtrls, Math;

type

  { TInterestCalculator }

  TInterestCalculator = class(TForm)
    ExitBtn: TBitBtn;
    Calculate: TButton;
    Clear: TButton;
    Image: TImage;
    Info: TButton;
    DateStart: TDateEdit;
    Deposit: TEdit;
    Rate: TEdit;
    Days: TEdit;
    Total: TEdit;
    InterestAmount: TEdit;
    TitleStart: TLabel;
    TitleEnd: TLabel;
    CompoundInterestCaption: TLabel;
    Result: TLabel;
    Summa: TLabel;
    RateCaption: TLabel;
    DaysCaption: TLabel;
    DateStartCaption: TLabel;
    PercentageType: TLabel;
    SimpleInterest: TRadioButton;
    CompoundInterest: TRadioButton;
    procedure ExitBtnClick(Sender: TObject);
    procedure CalculateClick(Sender: TObject);
    procedure ClearClick(Sender: TObject);
    procedure ImageClick(Sender: TObject);
    procedure InfoClick(Sender: TObject);
    procedure InterestAmountChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure TitleStartClick(Sender: TObject);
    procedure SimpleInterestChange(Sender: TObject);
    procedure TotalChange(Sender: TObject);
  private

  public

  end;

var
  InterestCalculator: TInterestCalculator;

implementation

{$R *.lfm}

{ TInterestCalculator }

procedure TInterestCalculator.FormCreate(Sender: TObject);
begin
  SimpleInterest.Checked := True;
  DateStart.Date := Date;

  Constraints.MinWidth := 780;
  Constraints.MinHeight := 540;

  Scaled := True;
  AutoScroll := False;

  Image.Anchors := [akTop, akRight];
  Image.Stretch := True;
  Image.Proportional := True;
  Image.Center := True;

  Calculate.Anchors := [akLeft, akBottom];
  Clear.Anchors := [akLeft, akBottom];
  Info.Anchors := [akLeft, akBottom];
  ExitBtn.Anchors := [akRight, akBottom];

  Deposit.Anchors := [akLeft, akTop];
  Rate.Anchors := [akLeft, akTop];
  Days.Anchors := [akLeft, akTop];
  DateStart.Anchors := [akLeft, akTop];

  InterestAmount.Anchors := [akLeft, akTop];
  Total.Anchors := [akLeft, akTop];

  InterestAmount.ReadOnly := True;
  Total.ReadOnly := True;

  PercentageType.Anchors := [akTop, akRight];
  SimpleInterest.Anchors := [akTop, akRight];
  CompoundInterest.Anchors := [akTop, akRight];
end;

procedure TInterestCalculator.TitleStartClick(Sender: TObject);
begin

end;

procedure TInterestCalculator.SimpleInterestChange(Sender: TObject);
begin

end;

procedure TInterestCalculator.TotalChange(Sender: TObject);
begin

end;

procedure TInterestCalculator.ExitBtnClick(Sender: TObject);
begin
  Close;
end;

procedure TInterestCalculator.CalculateClick(Sender: TObject);
var
  S, P, I, r: Double;
  d: Integer;
  DateBegin: TDateTime;
begin
  if not TryStrToFloat(Deposit.Text, P) then
  begin
    ShowMessage('Ошибка! В поле "Сумма" нужно ввести число.');
    Deposit.SetFocus;
    Exit;
  end;

  if not TryStrToFloat(Rate.Text, r) then
  begin
    ShowMessage('Ошибка! В поле "Ставка" нужно ввести число.');
    Rate.SetFocus;
    Exit;
  end;

  if not TryStrToInt(Days.Text, d) then
  begin
    ShowMessage('Ошибка! В поле "Срок" нужно ввести целое число дней.');
    Days.SetFocus;
    Exit;
  end;

  if DateStart.Text = '' then
  begin
    ShowMessage('Ошибка! Выберите начальную дату.');
    DateStart.SetFocus;
    Exit;
  end;

  DateBegin := DateStart.Date;
  DateEnd := DateBegin + d;

  r := r / 100;

  if P <= 0 then
  begin
    ShowMessage('Сумма должна быть больше нуля.');
    Deposit.SetFocus;
    Exit;
  end;

  if r <= 0 then
  begin
    ShowMessage('Ставка должна быть больше нуля.');
    Rate.SetFocus;
    Exit;
  end;

  if d <= 0 then
  begin
    ShowMessage('Срок должен быть больше нуля.');
    Days.SetFocus;
    Exit;
  end;

  if SimpleInterest.Checked then
    S := P * (1 + (r * d) / 365)
  else
    S := P * Power(1 + r / 365, d);

  I := S - P;

  Total.Text := FloatToStrF(S, ffFixed, 10, 2);
  InterestAmount.Text := FloatToStrF(I, ffFixed, 10, 2);

end;

procedure TInterestCalculator.ClearClick(Sender: TObject);
begin
  Deposit.Clear;
  Rate.Clear;
  Days.Clear;
  DateStart.Clear;
  Total.Clear;
  InterestAmount.Clear;
end;

procedure TInterestCalculator.ImageClick(Sender: TObject);
begin

end;

procedure TInterestCalculator.InfoClick(Sender: TObject);
begin
  ShowMessage(
    'Справка по расчету процентов' + LineEnding + LineEnding +

    'Простые проценты:' + LineEnding +
    'S = P * (1 + r * d / 365)' + LineEnding +
    'I = S - P' + LineEnding + LineEnding +

    'Сложные проценты:' + LineEnding +
    'S = P * (1 + r / 365)^d' + LineEnding +
    'I = S - P' + LineEnding + LineEnding +

    'Обозначения:' + LineEnding +
    'P — начальная сумма вклада;' + LineEnding +
    'S — итоговая сумма;' + LineEnding +
    'I — начисленные проценты;' + LineEnding +
    'r — годовая ставка в долях;' + LineEnding +
    'd — срок начисления в днях.' + LineEnding + LineEnding +

    'Пример:' + LineEnding +
    'Если ставка 12%, то в расчетах r = 0.12.' + LineEnding +
    'Период начисления принимается равным одному дню.'
  );
end;

procedure TInterestCalculator.InterestAmountChange(Sender: TObject);
begin

end;

end.

